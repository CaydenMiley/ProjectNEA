﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;

namespace ProjectNEA
{
    class Wire
    {
        private List<Line> drawnWires;
        private Line currentWire;
        private Point startPoint;

        public Wire(Canvas canvas)
        {
            drawnWires = new List<Line>();

            canvas.MouseRightButtonDown += Canvas_MouseRightButtonDown;
            canvas.MouseMove += Canvas_MouseMove;
            canvas.MouseRightButtonUp += Canvas_MouseRightButtonUp;
        }

        private void Canvas_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            startPoint = e.GetPosition((UIElement)sender);

            currentWire = new Line
            {
                X1 = startPoint.X,
                Y1 = startPoint.Y,
                X2 = startPoint.X,
                Y2 = startPoint.Y,
                Stroke = Brushes.Black,
                StrokeThickness = 2
            };

            ((Canvas)sender).Children.Add(currentWire);
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (currentWire != null && e.RightButton == MouseButtonState.Pressed)
            {
                Point endPoint = e.GetPosition((UIElement)sender);
                currentWire.X2 = endPoint.X;
                currentWire.Y2 = endPoint.Y;
            }
        }

        private void Canvas_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (currentWire != null)
            {
                drawnWires.Add(currentWire);
                currentWire = null;
            }
        }
    }
}