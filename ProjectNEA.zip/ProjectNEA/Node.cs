﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Xml.Linq;

namespace ProjectNEA
{
    public class Node
    {
        public int Id { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public Ellipse Shape { get; set; }
        public int Row { get; }
        public int Column { get; }
        public bool IsVisible { get; set; } = true; // New property to track visibility

        public List<Node> nodes;
        public Node(int id, double x, double y)
        {
            Id = id;
            X = x;
            Y = y;


            // Creates a default Ellipse as the shape used to display the nodes
            Shape = new Ellipse
            {
                Width = 10,
                Height = 10,
                Fill = Brushes.Gray,
                Stroke = Brushes.Gray,
                StrokeThickness = 1
            };
            // Add a click event handler to the node
            Shape.MouseLeftButtonDown += Node_Click;
        }
        public void Node_Click(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show($"Clicked on Node {Id}");
        }
        public Point GetNodePosition()
        {
            double x = Canvas.GetLeft(Shape);
            double y = Canvas.GetTop(Shape);

            return new Point(x, y);
        }
        public List<Point> GetAllNodePositions()
        {
            List<Point> nodePositions = new List<Point>();

            foreach (Node node in nodes)
            {
                Point position = node.GetNodePosition();
                nodePositions.Add(position);
            }

            return nodePositions;
        }
    }
}
