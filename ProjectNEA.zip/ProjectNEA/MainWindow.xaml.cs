﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;



namespace ProjectNEA
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Node> nodes;
        private double gridSize = 30; // Set the size of your grid nodes
        private MoveableShapeManager MovementManager;


        public MainWindow()
        {
            InitializeComponent();
            Wire myWire = new Wire(canvas);
            nodes = new List<Node>();


            // Call a method to create nodes
            CreateNodes();
            MoveableShapeManager MovementManager = new MoveableShapeManager(canvas, nodes);
            
            




        }
        

        private void CreateNodes()
        {
            MovementManager = new MoveableShapeManager(canvas, nodes);

            // Define the area where nodes will be created
            double areaTop = 250;
            double areaLeft = 350;
            double horizontalSpacing = 40;
            double verticalSpacing = 40;

            // Number of rows and columns
            int rows = 10;
            int columns = 15;

            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < columns; col++)
                {
                    // Calculate the position of the node
                    double x = areaLeft + col * horizontalSpacing;
                    double y = areaTop + row * verticalSpacing;

                    // Create a node with a unique identifier and coordinates
                    Node node = new Node((row * columns) + col + 1, x, y);

                    // Set the position of the node on the Canvas
                    Canvas.SetTop(node.Shape, node.Y);
                    Canvas.SetLeft(node.Shape, node.X);

                    // Add the node to the Canvas
                    canvas.Children.Add(node.Shape);

                    // Add the node to the list
                    nodes.Add(node);
                }
            }
        }
    }
}
