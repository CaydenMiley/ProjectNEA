﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows;
using System.Drawing;
using System.Windows.Shapes;
using static ProjectNEA.MoveableShapeManager;

namespace ProjectNEA
{

    public class MoveableShapeManager
    {
        private System.Windows.Shapes.Rectangle draggableShape;
        private Canvas canvas;
        private List<Node> nodes;

        public MoveableShapeManager(Canvas canvas, List<Node> nodes)
        {
            this.canvas = canvas;
            this.nodes = nodes;

            InitializeDraggableShape(ShapeType.Ellipse);
            InitializeDraggableShape(ShapeType.Rectangle);
        }
        private void SpawnLampButton_Click(object sender, RoutedEventArgs e)
        {
            // Call InitializeDraggableShape with the desired ShapeType
            InitializeDraggableShape(ShapeType.Ellipse);
        }

        public void InitializeDraggableShape(ShapeType shapeType)
        {
            Shape shape;

            switch (shapeType) // Switch statement to handle different cases based on the value of 'ShapeType'

            {
                case ShapeType.Rectangle:
                    shape = new System.Windows.Shapes.Rectangle
                    {
                        Width = 30,
                        Height = 30,
                        Fill = Brushes.Blue,
                        Opacity = 1,
                    };
                    break;

                case ShapeType.Ellipse:
                    shape = new Ellipse
                    {
                        Width = 30,
                        Height = 30,
                        Fill = Brushes.Red,
                        Opacity = 1,
                    };
                    break;



                default:
                    throw new ArgumentOutOfRangeException(nameof(shapeType), shapeType, null);
            }

            Canvas.SetZIndex(shape, 1); // Makes sure you can't the nodes if a shape is placed on top since the shape is set to be above it
            shape.MouseLeftButtonDown += DraggableShape_MouseLeftButtonDown;
            shape.MouseMove += DraggableShape_MouseMove;
            shape.MouseLeftButtonUp += DraggableShape_MouseLeftButtonUp;

            canvas.Children.Add(shape);
        }

        public enum ShapeType // Enumeration of all the types of components that can be made
        {
            Rectangle,
            Ellipse,

        }

        private void DraggableShape_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is Shape shape)
            {
                shape.CaptureMouse();
            }
        }

        private void DraggableShape_MouseMove(object sender, MouseEventArgs e)
        {
            if (sender is Shape shape && shape.IsMouseCaptured)
            {
                System.Windows.Point mousePosition = e.GetPosition(canvas);
                Canvas.SetTop(shape, mousePosition.Y - (shape.ActualHeight / 2));
                Canvas.SetLeft(shape, mousePosition.X - (shape.ActualWidth / 2));

                Node snappedNode = FindNodeUnderShape(shape);
                foreach (Node node in nodes)
                {
                    node.Shape.Visibility = (node == snappedNode) ? Visibility.Hidden : Visibility.Visible;
                }
            }
        }

        private void DraggableShape_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (sender is Shape shape)
            {
                shape.ReleaseMouseCapture();

                Node snappedNode = FindNodeUnderShape(shape);

                if (snappedNode != null)
                {
                    SnapToNode(shape, snappedNode);
                }
            }
        }

        private Node FindNodeUnderShape(Shape shape)
        {
            return nodes.FirstOrDefault(node => IsShapeOverlappingNode(shape, node));
        }

        private bool IsShapeOverlappingNode(Shape shape, Node node)
        {
            Rect shapeRect = new Rect(Canvas.GetLeft(shape), Canvas.GetTop(shape), shape.ActualWidth, shape.ActualHeight);
            Rect nodeRect = new Rect(Canvas.GetLeft(node.Shape), Canvas.GetTop(node.Shape), node.Shape.ActualWidth, node.Shape.ActualHeight);

            return shapeRect.IntersectsWith(nodeRect);
        }

        private void SnapToNode(Shape shape, Node node)
        {
            double newTop = Canvas.GetTop(node.Shape) + (node.Shape.ActualHeight / 2) - (shape.ActualHeight / 2);
            double newLeft = Canvas.GetLeft(node.Shape) + (node.Shape.ActualWidth / 2) - (shape.ActualWidth / 2);

            Canvas.SetTop(shape, newTop);
            Canvas.SetLeft(shape, newLeft);
            Canvas.SetZIndex(node.Shape, 0);

            // Displays ID of node that is snapped to 
            //MessageBox.Show($"Snapped to Node {node.Id}");
        }
        
        
    }


}